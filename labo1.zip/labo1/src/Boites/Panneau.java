package Boites;

import javax.swing.JPanel;
import java.awt.*;

public class Panneau extends JPanel {

    public Panneau(Dimension dimension) {

        setPreferredSize(dimension);
        setSize(dimension);
    }
}
